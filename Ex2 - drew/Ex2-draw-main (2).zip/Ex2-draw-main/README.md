Ex2 - Drew
